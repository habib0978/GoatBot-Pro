# Advanced Lock Command

Place `lock.js` inside your GoatBot command directory.

Commands:
- `!lock on`
- `!lock off`
- `!lock status`
- `!lock name <name>`
- `!lock emoji <emoji>`
- Reply to one photo and use `!lock image`

The command stores protection settings in `cache/Islamic_bot.json`.

Note:
- This version keeps name/emoji restoration logic.
- Admin changes are ignored to reduce false positives.
- Image protection depends on the Facebook API/event behavior and the availability of a local protected image file.
